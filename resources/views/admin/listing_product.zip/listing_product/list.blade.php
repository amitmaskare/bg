@extends('layout.admin')
@section('content')

<div class="page-body">
                <!-- Container-fluid starts-->
                <div class="container-fluid">
                    <div class="page-header">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="page-header-left">
                                    <h3>Listings
                                       
                                    </h3>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <ol class="breadcrumb pull-right">
                                    <li class="breadcrumb-item">
                                        <a href="index.html">
                                            <i data-feather="home"></i>
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item">Listing</li>
                                    <li class="breadcrumb-item active">List</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Container-fluid Ends-->

                <!-- Container-fluid starts-->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                            <a href="{{route('addlistingproduct')}}" class="btn btn-primary mt-3 mr-3" style="width:10%;">Add
                            </a>
                                <div class="card-body order-datatable">
                                    <table class="display basic-1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Type</th>
                                                <th>Image</th>
                                                
                                                <th>Product</th>
                                               
                                                <th>Qty Status</th>
                                                <th>Price(Rs.)</th>
                                                <th>Create</th>
                                                <th>Status</th>
                                                <th>Bids</th>
                                                <th>Orders</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @if($data['product'])
                                         @php $sr=1; @endphp
                                     @foreach($data['product'] as $key=>$value)
                                         @if($value->type=='sale')
                                            <tr>
                                                <td>{{$value->id}}
                                                <div class="icon-circle">
                                                <a href="javascript:void(0)">
                                            <i class="fa fa-angle-down text-info ffs-2"></i>
                                            </a>
                                                    </div>
                                                </td>
                                                <td>
                                                <span class="badge badge-secondary">{{ucfirst($value->type)}}</span> 
                                                </td>
                                                <td>
                                                @php
                                                    $imagePath = 'uploads/product/' . $value->main_image;
                                                    $imageExists = $value->main_image && file_exists(public_path($imagePath));
                                                    $imageUrl = $imageExists ? asset($imagePath) : asset('assets/images/electronics/product/25.jpg');
                                                @endphp
                                                    <a href="{{$imageUrl}}" data-lightbox="product-image">
                                                @if($value->main_image && file_exists('uploads/product/'.$value->main_image))
                                                <img src="{{asset('uploads/product/'.$value->main_image)}}" alt="" width="50px" height="50px"> 
                                                @else
                                                <img src="{{asset('assets/images/electronics/product/25.jpg')}}" alt=""
                                                class="img-fluid lazyloaded" width="50px" height="50px">
                                                @endif  
                                            </a> 
                                            </td>
                                                <td><a href="{{url('listingproduct/view/' . $value->id)}}">{{ucfirst($value->name)}}</a></td>
                                                <td>
                                                List : <span class="badge badge-success">10</span><br>
                                                Avail : <span class="badge badge-warning mt-1">10</span>
                                                </td>
                                                <td>{{$value->price}}</td>
                                                <td>{{date('d-M-Y',strtotime($value->created_at))}}</td>
                                                <td>{{ucfirst($value->status)}}</td>
                                                <td><a href="{{route('bidlist')}}">0</a></td>
                                                <td><a href="javascript:void(0)">0</a></td>
                                                <td>
                                                <div>
                                                <a href="#" onclick="viewProductInformation({{$value->id}})" title="view"><i class="fa fa-eye me-2 font-success"></i></a>
                                                <a href="{{ url('listingproduct/edit/' . $value->id) }}" title="Edit"><i class="fa fa-edit me-2 font-success"></i></a>
                                                <a href="javascript:void(0)" onclick="deleteListingProduct({{$value->id}})" title="Delete"><i class="fa fa-trash font-danger text-danger"></i></a>
                                                <a href="javascript:void(0)"  title="Delete"><i class="fab fa-firstdraft font-warning"></i></a>
                                            </div>
                                                </td>
                                            </tr>  
                                            @endif
                                        @endforeach

                                          @else
                                         <tr>
                                     <td colspan="11"><center>No Data Found</center></td>
                                             </tr>
                                         @endif     
                                          
                                        </tbody>
                                    </table>
                                </div>

                                <div class="card-body order-datatable mt-5">
                                    <table class="display basic-1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Type</th>
                                                <th>Image</th>
                                                
                                                <th>Product</th>
                                               
                                                <th>Qty Status</th>
                                                <th>Price(Rs.)</th>
                                                <th>Create</th>
                                                <th>Status</th>
                                                <th>Bids</th>
                                                <th>Orders</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @if($data['product'])
                                         @php $sr=1; @endphp
                                     @foreach($data['product'] as $key=>$value)
                                         @if($value->type=='purchase')
                                            <tr>
                                                <td>
                                                <div class="icon-circle">
                                                <a href="{{ url('listingproduct/view/' . $value->id) }}">
                                            <i class="fa fa-plus text-info" title="View Detail"></i>
                                            </a>
                                                    </div>
                                                </td>
                                                <td>
                                                <span class="badge badge-warning">{{ucfirst($value->type)}}</span> 
                                                </td>
                                                <td>
                                                @php
    $imagePath = 'uploads/product/' . $value->main_image;
    $imageExists = $value->main_image && file_exists(public_path($imagePath));
    $imageUrl = $imageExists ? asset($imagePath) : asset('assets/images/electronics/product/25.jpg');
@endphp
                                                    <a href="{{$imageUrl}}" data-lightbox="product-image">
                                                @if($value->main_image && file_exists('uploads/product/'.$value->main_image))
                                                <img src="{{asset('uploads/product/'.$value->main_image)}}" alt="" width="50px" height="50px"> 
                                                @else
                                                <img src="{{asset('assets/images/electronics/product/25.jpg')}}" alt=""
                                                class="img-fluid lazyloaded" width="50px" height="50px">
                                                @endif    
                                            </td>
                                                <td>{{ucfirst($value->name)}}</td>
                                                <td>
                                                List : <span class="badge badge-success">10</span><br>
                                                Avail : <span class="badge badge-warning mt-1">10</span>
                                                </td>
                                                <td>{{$value->price}}</td>
                                                <td>{{date('d-M-Y',strtotime($value->created_at))}}</td>
                                                <td>{{ucfirst($value->status)}}</td>
                                                <td><a href="{{route('bidlist')}}">0</a></td>
                                                <td><a href="javascript:void(0)">0</a></td>
                                                <td>
                                                <div>
                                                <a href="{{ url('listingproduct/edit/' . $value->id) }}" title="Edit"><i class="fa fa-edit me-2 font-success"></i></a>
                                                <a href="javascript:void(0)" onclick="deleteListingProduct({{$value->id}})" title="Delete"><i class="fa fa-trash font-danger text-danger"></i></a>
                                            </div>
                                                </td>
                                            </tr>  
                                            @endif
                                        @endforeach

                                          @else
                                         <tr>
                                     <td colspan="11"><center>No Data Found</center></td>
                                             </tr>
                                         @endif     
                                          
                                        </tbody>
                                    </table>
                                </div>

                              
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Container-fluid Ends-->
            </div> 


            <div class="modal fade" id="editBannerModal" tabindex="-1" aria-labelledby="editBannerModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title">Product Information</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                    <label>Category :&nbsp;<span id="categoryinfo" ></span></label>
                            </div>
                            <div class="col-md-4">
                                <label>Sub Category :&nbsp;<span id="subcategory_name" ></span></label>
                            </div>
                            <div class="col-md-4">
                                <label>Product Name :&nbsp;<span id="product_name" ></span></label>
                            </div>
                            <div class="col-md-4"  style="margin-top:20px;">
                                <label>Type :&nbsp;<span id="type" style="background-color:#13c9ca;padding:5px;color:#fff"></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Sale type :&nbsp;<span id="sale_type" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Quality :&nbsp;<span id="quality" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Date :&nbsp;<span id="date" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Quantity :&nbsp;<span id="quantity" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Price :&nbsp;<span id="price" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Item condition :&nbsp;<span id="item_condition" ></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Status :&nbsp;<span id="status" style="background-color:green;padding:5px;color:#fff"></span></label>
                            </div>
                            <div class="col-md-4" style="margin-top:20px;">
                                <label>Description :&nbsp;<span id="description" ></span></label>
                            </div>
                           
                            <div class="col-md-12" style="margin-top:20px;" id="tableData">
                            <h5>Additional Information :</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="extraFieldsTable" style="font-size:13px">
                                    <thead style="background-color:#13c9ca;color:#fff" >
                                    <tr>
                                        <th colspan="2" style="color:#fff">Specification Information</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <!-- JS will populate this -->
                                    </tbody>
                                </table>
                                </div>
                            </div>
                          
                        </div>
                        <div class="modal-footer">
                         
                        <button type="button" class="btn btn-success" data-bs-dismiss="modal" aria-label="Close"> close</button>
                        </div>
                    </div>
                    
                </div>
            </div>

@endsection

<!-- Add in your <head> -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet">

<!-- Add before </body> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<script src="{{ asset('js/custom.js') }}"></script>


<script>
      function deleteListingProduct(id) {
           var ask=confirm("Are you sure want to delete ?");
           if(ask==true)
           {
            window.location.href = "{{ url('listingproduct/delete') }}" + '/' + id;

           }
                       
        }
    function viewProductInformation(produId)
      {
      
        $.ajax({
                    url: "{{ url('getproductInfoforView') }}",
                    type: 'POST',
                    cache:false,
                    data: {
                        produId:produId,
                        _token: '{{ csrf_token() }}'
                    },
                    dataType:'json',
                    success:function(result)
                    {
                    
                      $('#editBannerModal').modal('show');        
                
                      $('#categoryinfo').html(result.categoryName);
                      $('#subcategory_name').html(result.subcategory_name);
                      $('#product_name').html(result.product_name);
                      $('#type').html(result.type);
                      $('#sale_type').html(result.sale_type);
                      $('#quality').html(result.quality);
                      $('#date').html(result.date);
                      $('#quantity').html(result.quantity);
                      $('#price').html(result.price);
                      $('#item_condition').html(result.item_condition);
                      $('#description').html(result.description);
                      $('#status').html(result.status);
                        if(result.extra_fields==''){
                            $('#tableData').css('display','none');

                        }
                      const tbody = document.querySelector("#extraFieldsTable tbody");
                        tbody.innerHTML = ''; // Clear previous rows

                        const extraFields = result.extra_fields || {};

                        Object.entries(extraFields).forEach(([key, value]) => {
                            const row = `<tr>
                                <td>${key}</td>
                                <td>${value}</td>
                            </tr>`;
                            tbody.insertAdjacentHTML('beforeend', row);
                        });


                    }
                });
      }
</script>
